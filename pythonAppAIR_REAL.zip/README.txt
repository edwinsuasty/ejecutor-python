
Este archivo .fla ha sido preparado para Adobe Animate 24.0.3 con lo siguiente:

- Campo de texto de entrada para código Python.
- Botón para enviar al servidor remoto (requiere backend con Flask o similar).
- Campo de salida con la respuesta.
- Código ActionScript 3 embebido en el fotograma 1.
- Publicar como Adobe AIR Desktop.

Edita la URL en el código para usar tu propio backend Python.

Si necesitas el archivo con componentes visuales diseñados en la Escena, indícalo y te lo preparamos.
